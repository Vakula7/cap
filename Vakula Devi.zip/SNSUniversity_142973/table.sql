
SQL> CREATE TABLE Candidate_Detail
  2  (applyId Number Primary Key,
  3  firstName varchar2(20),
  4  lastName varchar2(20),
  5  contactNo number(10),
  6  email varchar2(30),
  7  aggregate number(5,2),
  8  stream varchar2(25));

Table created.

SQL> CREATE SEQUENCE apply_id_seq
  2  MINVALUE 1000
  3  MAXVALUE 99999
  4  START WITH 1001
  5  INCREMENT BY 1
  6  NOCACHE;

Sequence created.