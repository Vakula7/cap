package com.capgemini.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.capgemini.exception.ApplicantException;

public class DBConnection {
	
	public static Connection getConnection() throws ApplicantException
	{
		Connection con=null;
		try {
			Properties prop=new Properties();
			FileReader fr=new FileReader("resources/jdbc.properties");
			prop.load(fr);
			String driver=prop.getProperty("driver");
			String url=prop.getProperty("dburl");
			String user=prop.getProperty("dbuser");
			String pass=prop.getProperty("dbpass");
			con=DriverManager.getConnection(url,user,pass);
		} catch (FileNotFoundException e) {
			System.out.println("JDBC property file not found "+e.getMessage());
		} catch (IOException e) {
			System.out.println("Unable to read the file "+e.getMessage());
		} catch (SQLException e) {
			System.out.println("Unable to connect to database "+e.getMessage());
		}
		return con;
		
	}

}
