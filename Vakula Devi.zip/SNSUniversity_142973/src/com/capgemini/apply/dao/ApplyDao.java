package com.capgemini.apply.dao;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.exception.ApplicantException;

public interface ApplyDao {
	
	public int addApplicantDetails(ApplicantBean applicant)throws ApplicantException;
	public ApplicantBean getApplicantDetails(int applicantID)throws ApplicantException;

}
