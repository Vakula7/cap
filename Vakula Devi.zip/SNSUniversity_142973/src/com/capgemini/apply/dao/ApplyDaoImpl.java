package com.capgemini.apply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.exception.ApplicantException;
import com.capgemini.util.DBConnection;

public class ApplyDaoImpl implements ApplyDao{
private static Logger log=Logger.getLogger(ApplyDaoImpl.class);
	
	public  ApplyDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {
		log.info("ADD APPLICANT CALLED");
		int count=0,count1=0;
		
		Connection con=DBConnection.getConnection();
		log.debug("CONNECTION SUCCESS");
		String qry=QueryMapper.INSERT_QUERY;
		try {
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setString(1, applicant.getfName());
			pstmt.setString(2, applicant.getlName());
			pstmt.setLong(3, applicant.getContactNo());
			pstmt.setString(4, applicant.getEmail());
			pstmt.setFloat(5, applicant.getAggregate());
			pstmt.setString(6, applicant.getStream());
			count=pstmt.executeUpdate();
			if(count>0)
			{
				log.info("INSERTION OF APPLICANT INFO SUCCESS");
				String qry1 = QueryMapper.SELECT_ID_QUERY;
				pstmt = con.prepareStatement(qry1);
				ResultSet rst = pstmt.executeQuery();
				if (rst.next()) {
					count1 = rst.getInt(1);
					
				} 
				else
				{
					log.debug("READ FROM SEQUENCE FAIL");
					throw new ApplicantException("Unable to read from sequence");
				}
			}
			if(count<0)
			{
				log.debug("INSERTION FAIL");
				throw new ApplicantException("INSERTION FAIL");
			}
			log.debug("CONNECTION CLOSE");
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new ApplicantException("INSERTION FAIL"+e.getMessage());
		}
		return count1;
	}

	@Override
	public ApplicantBean getApplicantDetails(int applicantID)
			throws ApplicantException {
		log.info("VIEW APPLICANT DETAILS CALLED");
		Connection con=DBConnection.getConnection();
		log.debug("CONNECTION SUCCESS");
		String qry=QueryMapper.SELECT_APPLICANT_BY_ID_QUERY;
		ApplicantBean abean=new ApplicantBean();;
		try {
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, applicantID);
			ResultSet rst = pstmt.executeQuery();
			if (rst.next()) {
				log.info("VIEW APPLICANT DETAILS SUCCESS");
				abean.setApplyId(rst.getInt("applyId"));
				abean.setfName(rst.getString("firstname"));
				abean.setlName(rst.getString("lastName"));
				abean.setContactNo(rst.getLong("contactNo"));
				abean.setEmail(rst.getString("email"));
				abean.setAggregate(rst.getFloat("aggregate"));
				abean.setStream(rst.getString("stream"));
			}
			if(abean.getApplyId()!=0)
			{
				log.info("VIEW APPLICANT DETAILS SUCCESS");
			}
			else
			{
				log.info("VIEW APPLICANT DETAILS FAILED----NO SUCH ID");
			}
			log.debug("CONNECTION CLOSE");
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new ApplicantException("SELECTION FAIL"+e.getMessage());
		}
		return abean;
	}

}
