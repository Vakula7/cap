package com.capgemini.apply.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="insert into Candidate_Detail(applyId,firstName,lastName,contactNo,email,aggregate,stream) values(apply_id_seq.nextval,?,?,?,?,?,?)";
	public static final String SELECT_ID_QUERY="select apply_id_seq.currval from Candidate_Detail";
	public static final String SELECT_APPLICANT_BY_ID_QUERY="select applyId,firstName,lastName,contactNo,email,aggregate,stream from Candidate_Detail where applyId=?";

}
