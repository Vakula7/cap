package com.capgemini.contact.service;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.exception.ApplicantException;

public interface ApplyService {

	public int addApplicantDetails(ApplicantBean apply)throws ApplicantException;
	public ApplicantBean getApplicantDetails(int applicantID)throws ApplicantException;
	public boolean isValidApplicant(ApplicantBean applicant)throws ApplicantException;
	
}
