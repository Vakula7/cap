package com.capgemini.contact.service;

import java.util.regex.Pattern;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.exception.ApplicantException;

public class ApplyServiceImpl implements ApplyService{
	ApplyDao dao=new ApplyDaoImpl();
	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {
		int count=0;
		boolean flag=isValidApplicant(applicant);
		if(flag==true)
		{
			count=dao.addApplicantDetails(applicant);
		}
		return count;
	}

	@Override
	public ApplicantBean getApplicantDetails(int applicantID)
			throws ApplicantException {
		ApplicantBean abean=new ApplicantBean();
		abean=dao.getApplicantDetails(applicantID);
		return abean;
	}

	@Override
	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException {
			boolean flag=false;
		if(validatefName(applicant.getfName()))
		{
			if(validatelName(applicant.getlName()))
			{
				if(validateContactNum(applicant.getContactNo()))
				{
					if(validateMailId(applicant.getEmail()))
					{
						if(validateAggregate(applicant.getAggregate()))
						{
							if(validateStream(applicant.getStream()))
							{
								flag=true;
							}
							else
								throw new ApplicantException("Please enter valid stream");
						}
						else
							throw new ApplicantException("Please enter valid aggregate number");
					}
					else
						throw new ApplicantException("Please enter valid mail id");
				}
				else
					throw new ApplicantException("Please enter valid contact number");
			}
			else
				throw new ApplicantException("Please enter valid last name");
		}
		else
			throw new ApplicantException("Please enter valid first name");
		return flag;
	}
	
	public boolean validateContactNum(long mobNum)
	{
		boolean b=Pattern.matches("[6-9][0-9]{9}", String.valueOf(mobNum));
		return b;
	}
	public boolean validatefName(String fname)
	{
		boolean b=Pattern.matches("[A-Za-z]{3,20}", String.valueOf(fname));
		return b;
	}
	public boolean validateStream(String stream)
	{
		boolean b=false;
		String[] arr={"Computer sc","Computer Science","Information Technology","IT","CS","CSE","Computer sc."};
		for(int i=0;i<arr.length;i++)
		{
			if(stream.equalsIgnoreCase(arr[i]))
			{
				b=true;
				break;
			}
		}
		return b;
	}
	public boolean validateAggregate(float aggre)
	{
		boolean b=Pattern.matches("[0-9]{1,20}.[0-9]{1,9}", String.valueOf(aggre));
		return b;
	}
	public boolean validateMailId(String mailId)
	{
		boolean b=Pattern.matches("[a-z]{1}[a-z0-9]{1,15}@[a-z]{3,10}.[a-z]{3}", String.valueOf(mailId));
		return b;
	}
	public boolean validatelName(String lname)
	{
		boolean b=Pattern.matches("[A-Za-z]{3,20}", String.valueOf(lname));
		return b;
	}
	

}
