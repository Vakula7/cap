package com.capgemini.contact.ui;

import java.util.Scanner;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.service.ApplyService;
import com.capgemini.contact.service.ApplyServiceImpl;
import com.capgemini.exception.ApplicantException;

public class Client {
	
	
	public static void main(String[] args) {
		ApplyService service = new ApplyServiceImpl();
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		int n=1;
		System.out.println("**********Admission System*********");
		while(n!=0)
		{
			
			System.out.println("Select an operation");
			System.out.println("1.Enter Details");
			System.out.println("2.View Details based on Applicant Id");
			System.out.println("0.Exit");
			System.out.println("**********************");
			System.out.print("Please enter a choice : ");
			int choice=sc.nextInt();
			System.out.println();
			
			switch(choice)
			{
			case 1:
				try {
					System.out.println("**********************");
					System.out.println();
					System.out.print("Enter First Name : ");
					String fname=sc1.nextLine();
					System.out.print("Enter Last Name : ");
					String lname=sc1.nextLine();
					System.out.print("Enter Contact Number : ");
					long contNum=sc.nextLong();
					System.out.print("Enter email : ");
					String email=sc1.nextLine();
					System.out.print("Enter Stream : ");
					String stream=sc1.nextLine();
					System.out.print("Enter Aggregate in qualifying exam : ");
					float aggre=sc.nextFloat();
					ApplicantBean abean=new ApplicantBean();
					abean.setfName(fname);
					abean.setlName(lname);
					abean.setContactNo(contNum);
					abean.setEmail(email);
					abean.setStream(stream);
					abean.setAggregate(aggre);
					System.out.println();
					System.out.println("*******************************");
					int count=service.addApplicantDetails(abean);
					if(count>0)
					{
					System.out.println("Thank you "+abean.getfName()+" "+abean.getlName()+" your Unique Id is "+count+" we will contact you shorltly.");
					System.out.println();
					System.out.println("********************************");
					System.out.println();
					}
					else
						System.out.println("Insertion fail");
				} catch (ApplicantException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				try {
					System.out.println("**********************");
					System.out.print("Enter the Application Id : ");
					int id=sc.nextInt();
					ApplicantBean abean1=new ApplicantBean();
					abean1=service.getApplicantDetails(id);
					if(abean1.getApplyId()!=0)
					{
						System.out.println();
						System.out.println("Id   First Name  Last Name    Contact No.  Stream  Aggregate  Email ");
						System.out.println(abean1.getApplyId()+" "+abean1.getfName()+"      "+abean1.getlName()+"    "+abean1.getContactNo()+"    "+abean1.getStream()+"    "+abean1.getAggregate()+"      "+abean1.getEmail());
						System.out.println();
					}
					else
						System.out.println("Sorry no details found!!");
				} catch (ApplicantException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 0:
				System.out.println("Thank you for applying !!");
				n=0;
				break;
			}
		}
		sc.close();
		sc1.close();
	}
}
