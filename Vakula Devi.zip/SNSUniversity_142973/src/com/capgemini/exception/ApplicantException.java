package com.capgemini.exception;

public class ApplicantException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4477002455556572364L;

	public ApplicantException(String message) {
		super(message);
	}

}
