package com.capgemini.test;
import static org.junit.Assert.*;

import org.junit.*;

import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.exception.ApplicantException;

public class TestApplyDao {
	static ApplyDaoImpl dao;
	static ApplicantBean bean;
	
	@BeforeClass
	public static void init() {
		dao= new ApplyDaoImpl();
		bean=new ApplicantBean();
	}
	
	@Test
	public void testAddApplicant() {
		bean.setfName("Sona");;
		bean.setlName("Ragupathy");;
		try {
			Integer id = dao.addApplicantDetails(bean);
			assertNotNull(id);

		} catch (ApplicantException e) {
			System.out.println("");
		}
	}
	
	@Test
	public void testViewApplicant() throws ApplicantException
	{
		bean.setApplyId(1001);
		assertNotNull(dao.getApplicantDetails(bean.getApplyId()));
	}
	
	@AfterClass
	public static void after() {
		dao = null;
		bean = null;
	}
	
	
}
