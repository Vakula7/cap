package com.cg.elm.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1537544140247561257L;

	public EmployeeException(String message) {
		super(message);
		
	}
	
	

}
