package com.cg.elm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.elm.bean.EmployeeDetails;
import com.cg.elm.bean.EmployeeLeaveDetails;
import com.cg.elm.dao.IEmployeeDao;
import com.cg.elm.exception.EmployeeException;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDao dao;

	public IEmployeeDao getDao() {
		return dao;
	}

	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public EmployeeDetails findEmployeeById(int id) {
		return dao.findEmployeeById(id);
	}

	@Override
	public List<EmployeeLeaveDetails> fetchLeaveHistory(int id)
			throws EmployeeException {
		return dao.fetchLeaveHistory(id);
	}

}
