package com.cg.elm.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="employee_details")
public class EmployeeDetails {
	
	@Id
	private int empid;
	
	private String ename;
	
	private String address;
	
	@Column(name="leaves_avail")
	private int leaveAvail;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getLeaveAvail() {
		return leaveAvail;
	}
	public void setLeaveAvail(int leaveAvail) {
		this.leaveAvail = leaveAvail;
	}
	@Override
	public String toString() {
		return "EmployeeDetails [empid=" + empid + ", ename=" + ename
				+ ", address=" + address + ", leaveAvail=" + leaveAvail + "]";
	}
	
	

}
