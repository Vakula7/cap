package com.cg.elm.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_leave_details")
public class EmployeeLeaveDetails {
	
	@Id
	@Column(name="leave_id")
	private int leaveId;
	
	private int empid;
	
	@Column(name="start_date")
	private Date startDate;
	
	@Column(name="end_date")
	private Date endDate;
	
	private String description;
	
	@Column(name="leaves_applied")
	private int leaveApplied;

	public int getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getLeaveApplied() {
		return leaveApplied;
	}

	public void setLeaveApplied(int leaveApplied) {
		this.leaveApplied = leaveApplied;
	}

	@Override
	public String toString() {
		return "EmployeeLeaveDetails [leaveId=" + leaveId + ", empid=" + empid
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", description=" + description + ", leaveApplied="
				+ leaveApplied + "]";
	}
	
	

}
