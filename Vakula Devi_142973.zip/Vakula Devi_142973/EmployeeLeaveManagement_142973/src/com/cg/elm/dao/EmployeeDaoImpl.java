package com.cg.elm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.elm.bean.EmployeeDetails;
import com.cg.elm.bean.EmployeeLeaveDetails;
import com.cg.elm.exception.EmployeeException;



@Repository
public class EmployeeDaoImpl implements IEmployeeDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public EmployeeDetails findEmployeeById(int id) {
		EmployeeDetails ebean=(EmployeeDetails)entityManager.find(EmployeeDetails.class, id);
		return ebean;
	}

	@Override
	public List<EmployeeLeaveDetails> fetchLeaveHistory(int id)
			throws EmployeeException {
		List<EmployeeLeaveDetails> list=null;
		try {
			TypedQuery<EmployeeLeaveDetails> qry=entityManager.createQuery("select t from EmployeeLeaveDetails t where t.empid=:id", EmployeeLeaveDetails.class);
			qry.setParameter("id", id);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("No records for Employee Leave Details");
		}
		return list;
		
	}
	
	

}
