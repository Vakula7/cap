package com.cg.elm.dao;

import java.util.List;

import com.cg.elm.bean.EmployeeDetails;
import com.cg.elm.bean.EmployeeLeaveDetails;
import com.cg.elm.exception.EmployeeException;


public interface IEmployeeDao {

	public EmployeeDetails findEmployeeById(int id);
	public List<EmployeeLeaveDetails> fetchLeaveHistory(int id) throws EmployeeException;
}
