package com.cg.elm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.elm.bean.EmployeeDetails;
import com.cg.elm.bean.EmployeeLeaveDetails;
import com.cg.elm.exception.EmployeeException;
import com.cg.elm.service.IEmployeeService;



@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping("/HomePage")
	public ModelAndView showHomePage() {
		EmployeeDetails ebean = new EmployeeDetails();
		return new ModelAndView("Home", "empDetails", ebean);
	}

	@RequestMapping("/viewHistory")
	public ModelAndView showProductById(
			@ModelAttribute("empDetails") @Valid EmployeeDetails ebean,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			EmployeeDetails emp=service.findEmployeeById(ebean.getEmpid());
			if(emp!=null)
			{
				try {
					List<EmployeeLeaveDetails> list=service.fetchLeaveHistory(emp.getEmpid());
					if(!list.isEmpty())
					{
						mv=new ModelAndView("ViewLeaveDetails");
						mv.addObject("id", emp.getEmpid());
						mv.addObject("name", emp.getEname());
						mv.addObject("list",list);
					}
					else
					{
						mv=new ModelAndView("ViewLeaveDetails");
						mv.addObject("id", emp.getEmpid());
						mv.addObject("name", emp.getEname());
						mv.addObject("isStatus","true");
						mv.addObject("msg","No Leave Record Found");
					}
				} catch (EmployeeException e) {
					mv=new ModelAndView("ViewLeaveDetails");
					mv.addObject("msg",e.getMessage());
				}
				
			}
			else
			{
				String msg="This Employee ID Does not exist..";
				EmployeeDetails ebean2 = new EmployeeDetails();
				mv = new ModelAndView("Home", "msg", msg);
				mv.addObject("empDetails",ebean2);
			}
			

		} else {
			mv = new ModelAndView("Home", "empDetails", ebean);
		}

		return mv;

	}

}
